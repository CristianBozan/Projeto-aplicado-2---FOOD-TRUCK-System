-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: localhost    Database: sistema_pedidos
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `atendentes`
--

DROP TABLE IF EXISTS `atendentes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `atendentes` (
  `id_atendente` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL,
  `cpf` char(11) NOT NULL,
  `telefone` varchar(20) DEFAULT NULL,
  `login` varchar(50) NOT NULL,
  `senha` varchar(255) NOT NULL,
  `tipo_usuario` enum('gerente','atendente') DEFAULT 'atendente',
  `criado_em` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `atualizado_em` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_atendente`),
  UNIQUE KEY `cpf` (`cpf`),
  UNIQUE KEY `login` (`login`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `atendentes`
--

LOCK TABLES `atendentes` WRITE;
/*!40000 ALTER TABLE `atendentes` DISABLE KEYS */;
INSERT INTO `atendentes` VALUES (1,'Guilherme','12345678901','47999999999','admin','admin123','gerente','2025-10-22 23:24:22','2025-11-21 05:19:24'),(7,'Cristian','06953802901','48998190210','atendente01','atendente01','atendente','2025-11-21 00:11:11','2025-11-21 00:11:11'),(8,'Michel','000000000','578956.52.2','atendente02','atendente02','atendente','2025-11-21 03:24:56','2025-11-21 03:24:56');
/*!40000 ALTER TABLE `atendentes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `itens_pedido`
--

DROP TABLE IF EXISTS `itens_pedido`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `itens_pedido` (
  `id_item` int NOT NULL AUTO_INCREMENT,
  `quantidade` int NOT NULL,
  `preco_unitario` decimal(10,2) NOT NULL,
  `subtotal` decimal(10,2) NOT NULL,
  `id_pedido` int DEFAULT NULL,
  `id_produto` int DEFAULT NULL,
  `criado_em` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `atualizado_em` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_item`),
  KEY `id_pedido` (`id_pedido`),
  KEY `id_produto` (`id_produto`),
  CONSTRAINT `itens_pedido_ibfk_1` FOREIGN KEY (`id_pedido`) REFERENCES `pedidos` (`id_pedido`),
  CONSTRAINT `itens_pedido_ibfk_2` FOREIGN KEY (`id_produto`) REFERENCES `produtos` (`id_produto`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `itens_pedido`
--

LOCK TABLES `itens_pedido` WRITE;
/*!40000 ALTER TABLE `itens_pedido` DISABLE KEYS */;
INSERT INTO `itens_pedido` VALUES (9,1,32.00,32.00,22,7,'2025-11-22 00:12:44','2025-11-22 00:12:44'),(10,1,42.00,42.00,22,6,'2025-11-22 00:12:44','2025-11-22 00:12:44'),(11,1,27.00,27.00,22,3,'2025-11-22 00:12:44','2025-11-22 00:12:44'),(12,3,6.00,18.00,22,2,'2025-11-22 00:12:44','2025-11-22 00:12:44'),(13,1,27.00,27.00,23,3,'2025-11-22 00:14:14','2025-11-22 00:14:14'),(14,1,6.00,6.00,23,2,'2025-11-22 00:14:14','2025-11-22 00:14:14'),(15,1,27.00,27.00,24,3,'2025-11-22 00:20:17','2025-11-22 00:20:17'),(16,1,42.00,42.00,24,6,'2025-11-22 00:20:17','2025-11-22 00:20:17'),(17,2,20.00,40.00,25,1,'2025-11-22 00:34:45','2025-11-22 00:34:45'),(18,2,6.00,12.00,25,2,'2025-11-22 00:34:45','2025-11-22 00:34:45'),(19,1,6.00,6.00,27,2,'2025-11-22 00:39:29','2025-11-22 00:39:29'),(20,1,27.00,27.00,27,3,'2025-11-22 00:39:29','2025-11-22 00:39:29'),(21,1,42.00,42.00,27,6,'2025-11-22 00:39:29','2025-11-22 00:39:29'),(22,1,20.00,20.00,30,1,'2025-11-22 00:49:11','2025-11-22 00:49:11'),(23,1,6.00,6.00,30,2,'2025-11-22 00:49:11','2025-11-22 00:49:11'),(24,1,27.00,27.00,30,3,'2025-11-22 00:49:11','2025-11-22 00:49:11'),(25,1,5.00,5.00,30,8,'2025-11-22 00:49:11','2025-11-22 00:49:11'),(26,2,27.00,54.00,31,3,'2025-11-22 00:51:06','2025-11-22 00:51:06'),(27,1,42.00,42.00,31,6,'2025-11-22 00:51:06','2025-11-22 00:51:06'),(28,2,5.00,10.00,31,8,'2025-11-22 00:51:06','2025-11-22 00:51:06'),(32,2,20.00,40.00,33,1,'2025-11-22 00:53:57','2025-11-22 00:53:57'),(33,1,6.00,6.00,33,2,'2025-11-22 00:53:57','2025-11-22 00:53:57');
/*!40000 ALTER TABLE `itens_pedido` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mesas`
--

DROP TABLE IF EXISTS `mesas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mesas` (
  `id_mesa` int NOT NULL AUTO_INCREMENT,
  `numero_mesa` int NOT NULL,
  `status` enum('livre','ocupada') DEFAULT 'livre',
  `criado_em` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `atualizado_em` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_mesa`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mesas`
--

LOCK TABLES `mesas` WRITE;
/*!40000 ALTER TABLE `mesas` DISABLE KEYS */;
INSERT INTO `mesas` VALUES (1,1,'livre','2025-10-22 23:24:22','2025-11-22 00:54:20'),(2,2,'livre','2025-10-22 23:24:22','2025-11-22 00:14:24'),(3,3,'livre','2025-10-23 02:09:51','2025-11-22 00:55:24'),(4,4,'livre','2025-11-21 00:00:02','2025-11-21 06:28:02');
/*!40000 ALTER TABLE `mesas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pedidos`
--

DROP TABLE IF EXISTS `pedidos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pedidos` (
  `id_pedido` int NOT NULL AUTO_INCREMENT,
  `data_hora` datetime DEFAULT CURRENT_TIMESTAMP,
  `forma_pagamento` enum('pix','credito','debito','dinheiro','mix') DEFAULT NULL,
  `status` enum('aberto','finalizado','cancelado','pago') NOT NULL DEFAULT 'aberto',
  `observacoes` text,
  `total` decimal(10,2) DEFAULT '0.00',
  `id_mesa` int DEFAULT NULL,
  `id_atendente` int DEFAULT NULL,
  `criado_em` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `atualizado_em` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_pedido`),
  KEY `id_mesa` (`id_mesa`),
  KEY `id_atendente` (`id_atendente`),
  CONSTRAINT `pedidos_ibfk_1` FOREIGN KEY (`id_mesa`) REFERENCES `mesas` (`id_mesa`),
  CONSTRAINT `pedidos_ibfk_2` FOREIGN KEY (`id_atendente`) REFERENCES `atendentes` (`id_atendente`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pedidos`
--

LOCK TABLES `pedidos` WRITE;
/*!40000 ALTER TABLE `pedidos` DISABLE KEYS */;
INSERT INTO `pedidos` VALUES (21,'2025-11-21 06:41:25','pix','pago','Teste automático',42.50,NULL,1,'2025-11-21 06:41:25','2025-11-21 06:41:25'),(22,'2025-11-22 00:12:44','dinheiro','pago','Pedido com 4 item(ns): x- gaucho (1x), X-Bacon (1x), X-galinha (1x), Refrigerante Lata 350ml (3x)',119.00,NULL,7,'2025-11-22 00:12:44','2025-11-22 00:13:41'),(23,'2025-11-22 00:14:14','pix','pago','Pedido com 2 item(ns): X-galinha (1x), Refrigerante Lata 350ml (1x)',33.00,NULL,8,'2025-11-22 00:14:14','2025-11-22 00:14:42'),(24,'2025-11-22 00:20:17','pix','pago','Pedido com 2 item(ns): X-galinha (1x), X-Bacon (1x)',69.00,NULL,NULL,'2025-11-22 00:20:17','2025-11-22 00:20:33'),(25,'2025-11-22 00:34:45','pix','pago','Pedido com 2 item(ns): X-Burger (2x), Refrigerante Lata 350ml (2x)',52.00,NULL,NULL,'2025-11-22 00:34:45','2025-11-22 00:35:20'),(26,'2025-11-22 00:39:08','credito','pago','Teste preserve atendente',12.50,NULL,1,'2025-11-22 00:39:08','2025-11-22 00:43:17'),(27,'2025-11-22 00:39:29','credito','pago','Pedido com 3 item(ns): Refrigerante Lata 350ml (1x), X-galinha (1x), X-Bacon (1x)',75.00,1,1,'2025-11-22 00:39:29','2025-11-22 00:43:30'),(28,'2025-11-22 00:40:40','dinheiro','pago','Teste preserve atendente',12.50,NULL,1,'2025-11-22 00:40:40','2025-11-22 00:42:40'),(29,'2025-11-22 00:41:56','pix','pago','Teste preserve atendente',12.50,NULL,1,'2025-11-22 00:41:56','2025-11-22 00:41:56'),(30,'2025-11-22 00:49:11','debito','pago','Pedido com 4 item(ns): X-Burger (1x), Refrigerante Lata 350ml (1x), X-galinha (1x), agua com gas 500ml (1x)',58.00,1,8,'2025-11-22 00:49:11','2025-11-22 00:54:20'),(31,'2025-11-22 00:51:06','dinheiro','pago','Pedido com 3 item(ns): X-galinha (2x), X-Bacon (1x), agua com gas 500ml (2x)',106.00,3,1,'2025-11-22 00:51:06','2025-11-22 00:52:29'),(33,'2025-11-22 00:53:57','credito','pago','Pedido com 2 item(ns): X-Burger (2x), Refrigerante Lata 350ml (1x)',46.00,3,7,'2025-11-22 00:53:57','2025-11-22 00:55:24');
/*!40000 ALTER TABLE `pedidos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `produtos`
--

DROP TABLE IF EXISTS `produtos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `produtos` (
  `id_produto` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL,
  `descricao` text,
  `preco` decimal(10,2) NOT NULL,
  `foto` varchar(255) DEFAULT NULL,
  `categoria` varchar(50) DEFAULT NULL,
  `quantidade_estoque` int DEFAULT '0',
  `status` enum('ativo','inativo') DEFAULT 'ativo',
  `criado_em` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `atualizado_em` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_produto`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `produtos`
--

LOCK TABLES `produtos` WRITE;
/*!40000 ALTER TABLE `produtos` DISABLE KEYS */;
INSERT INTO `produtos` VALUES (1,'X-Burger','O tradicional. Pão, hambúrguer de carne bovina, queijo mussarela e presunto. A essência do sabor.',20.00,'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRul2sfUQiCUO0o6koUtvS9SXovZhJrOijocA&s','Lanches',491,'ativo','2025-10-22 23:24:22','2025-11-22 00:53:57'),(2,'Refrigerante Lata 350ml','350ml',6.00,'https://andinacocacola.vtexassets.com/arquivos/ids/159186/44.jpg?v=638975402691170000','Bebida',85,'ativo','2025-10-22 23:24:22','2025-11-22 00:53:57'),(3,'X-galinha','',27.00,'https://imagens.jotaja.com/produtos/6dcc15bd-80cb-426f-acd7-2f52de6f75cb.jpg','Lanches',990,'ativo','2025-10-23 02:58:32','2025-11-22 00:51:06'),(6,'X-Bacon','Pão de hambúrguer, carne de hambúrguer, mussarela, bacon, alface, tomate, milho e batata palha',42.00,'https://imagens.jotaja.com/produtos/fc08d384-4d2e-497f-a16a-9184a807e908.jpg','Lanches',496,'ativo','2025-11-21 02:16:41','2025-11-22 00:51:06'),(7,'x- gaucho','tradicional x gaucho\n',32.00,'','Lanches',4998,'ativo','2025-11-22 00:11:51','2025-11-22 00:51:27'),(8,'agua com gas 500ml','agua com gas',5.00,'https://d21wiczbqxib04.cloudfront.net/aD-xzJEu7SyGl8BoheE25Utfj_I=/fit-in/453x453/filters:fill(FFFFFF):background_color(white)/https://produtos-osuper.s3.sa-east-1.amazonaws.com/7894900531008.jpg','Bebida',147,'ativo','2025-11-22 00:46:45','2025-11-22 00:51:06');
/*!40000 ALTER TABLE `produtos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sincronizacoes`
--

DROP TABLE IF EXISTS `sincronizacoes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sincronizacoes` (
  `id_sync` int NOT NULL AUTO_INCREMENT,
  `data_hora` datetime DEFAULT CURRENT_TIMESTAMP,
  `status` varchar(20) DEFAULT NULL,
  `id_atendente` int DEFAULT NULL,
  `id_pedido` int DEFAULT NULL,
  `criado_em` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `atualizado_em` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_sync`),
  KEY `id_atendente` (`id_atendente`),
  KEY `id_pedido` (`id_pedido`),
  CONSTRAINT `sincronizacoes_ibfk_1` FOREIGN KEY (`id_atendente`) REFERENCES `atendentes` (`id_atendente`),
  CONSTRAINT `sincronizacoes_ibfk_2` FOREIGN KEY (`id_pedido`) REFERENCES `pedidos` (`id_pedido`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sincronizacoes`
--

LOCK TABLES `sincronizacoes` WRITE;
/*!40000 ALTER TABLE `sincronizacoes` DISABLE KEYS */;
/*!40000 ALTER TABLE `sincronizacoes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vendas`
--

DROP TABLE IF EXISTS `vendas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vendas` (
  `id_venda` int NOT NULL AUTO_INCREMENT,
  `id_pedido` int DEFAULT NULL,
  `id_atendente` int DEFAULT NULL,
  `id_sync` int DEFAULT NULL,
  `data_hora` datetime DEFAULT CURRENT_TIMESTAMP,
  `forma_pagamento` enum('pix','credito','debito','dinheiro','mix') DEFAULT NULL,
  `valor_total` decimal(10,2) DEFAULT NULL,
  `valor_pago` decimal(10,2) DEFAULT NULL,
  `troco` decimal(10,2) DEFAULT NULL,
  `status` enum('confirmada','pendente','estornada') DEFAULT 'pendente',
  `comprovante` varchar(255) DEFAULT NULL,
  `observacoes` text,
  `criado_em` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `atualizado_em` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_venda`),
  UNIQUE KEY `id_pedido` (`id_pedido`),
  KEY `id_atendente` (`id_atendente`),
  KEY `id_sync` (`id_sync`),
  CONSTRAINT `vendas_ibfk_1` FOREIGN KEY (`id_pedido`) REFERENCES `pedidos` (`id_pedido`),
  CONSTRAINT `vendas_ibfk_2` FOREIGN KEY (`id_atendente`) REFERENCES `atendentes` (`id_atendente`),
  CONSTRAINT `vendas_ibfk_3` FOREIGN KEY (`id_sync`) REFERENCES `sincronizacoes` (`id_sync`)
) ENGINE=InnoDB AUTO_INCREMENT=81 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vendas`
--

LOCK TABLES `vendas` WRITE;
/*!40000 ALTER TABLE `vendas` DISABLE KEYS */;
INSERT INTO `vendas` VALUES (68,21,NULL,NULL,'2025-11-21 06:41:25','pix',42.50,NULL,NULL,'pendente',NULL,NULL,'2025-11-21 06:41:25','2025-11-21 06:41:25'),(69,22,NULL,NULL,'2025-11-22 00:13:06','dinheiro',119.00,NULL,NULL,'pendente',NULL,NULL,'2025-11-22 00:13:06','2025-11-22 00:13:06'),(70,23,NULL,NULL,'2025-11-22 00:14:24','pix',33.00,NULL,NULL,'pendente',NULL,NULL,'2025-11-22 00:14:24','2025-11-22 00:14:24'),(71,24,NULL,NULL,'2025-11-22 00:20:33','pix',69.00,NULL,NULL,'pendente',NULL,NULL,'2025-11-22 00:20:33','2025-11-22 00:20:33'),(72,25,NULL,NULL,'2025-11-22 00:35:20','pix',52.00,NULL,NULL,'pendente',NULL,NULL,'2025-11-22 00:35:20','2025-11-22 00:35:20'),(73,29,NULL,NULL,'2025-11-22 00:41:56','pix',12.50,NULL,NULL,'pendente',NULL,NULL,'2025-11-22 00:41:56','2025-11-22 00:41:56'),(74,28,NULL,NULL,'2025-11-22 00:42:40','dinheiro',12.50,NULL,NULL,'pendente',NULL,NULL,'2025-11-22 00:42:40','2025-11-22 00:42:40'),(75,26,NULL,NULL,'2025-11-22 00:43:17','credito',12.50,NULL,NULL,'pendente',NULL,NULL,'2025-11-22 00:43:17','2025-11-22 00:43:17'),(76,27,NULL,NULL,'2025-11-22 00:43:30','credito',75.00,NULL,NULL,'pendente',NULL,NULL,'2025-11-22 00:43:30','2025-11-22 00:43:30'),(78,31,NULL,NULL,'2025-11-22 00:52:29','dinheiro',106.00,NULL,NULL,'pendente',NULL,NULL,'2025-11-22 00:52:29','2025-11-22 00:52:29'),(80,33,NULL,NULL,'2025-11-22 00:55:24','credito',46.00,NULL,NULL,'pendente',NULL,NULL,'2025-11-22 00:55:24','2025-11-22 00:55:24');
/*!40000 ALTER TABLE `vendas` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-11-21 21:58:07
